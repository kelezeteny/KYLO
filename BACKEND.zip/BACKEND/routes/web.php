<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TermekController;
use App\Http\Controllers\KapcsolatController;

//Termék
Route::get('/termekek', [TermekController::class, "getTermekLista"]);
Route::get('/termekek/{id}', [TermekController::class, "getTermekAdatok"]);

//Kapcsolat
Route::get('/felhasznalok', [KapcsolatController::class, 'getFelhasznalok']);
Route::post('/kapcsolat', [KapcsolatController::class, 'kapcsolat']);