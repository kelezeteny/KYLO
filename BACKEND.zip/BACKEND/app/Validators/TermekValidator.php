<?php

namespace App\Validators;

use App\Models\Termek;

class TermekValidator{
    public function ellenoriz(Termek $termek) : array{
        $hibak = [];

        if(trim($termek->getNev() == '')){
            $hibak[] = 'A név kötelező.';
        }

        return $hibak;
    }
}