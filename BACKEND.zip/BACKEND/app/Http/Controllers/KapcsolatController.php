<?php

namespace App\Http\Controllers;

use App\Services\KapcsolatService;
use Illuminate\Http\Request;

class KapcsolatController extends Controller
{
    private KapcsolatService $kapcsolatService;

    public function __construct(){
        $this->kapcsolatService = new KapcsolatService();
    }

    public function getFelhasznalok(){
		$felhasznalo = $this->kapcsolatService->getFelhasznalok();
        return response()->json($felhasznalo, 200);
    }

    public function kapcsolat(){
        try{
            $kapcsolat = $this->kapcsolatService->kapcsolat();           
            return response()->json($kapcsolat);
            
        } catch(\Exception){
            return response()->json(null, 400);
        }
    }
}