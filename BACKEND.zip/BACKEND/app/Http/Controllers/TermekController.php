<?php

namespace App\Http\Controllers;

use App\Services\TermekService;
use Illuminate\Http\Request;
use App\Models\Termek;

class TermekController extends Controller
{
    private TermekService $termekService;

    public function __construct(){
        $this->termekService = new TermekService();
    }

    public function getTermekLista(){
        try{
            $lista = $this->termekService->getTermekLista();           
            return response()->json($lista);
            
        } catch(\Exception){
            return response()->json(null, 400);
        }
    }

    public function getTermekAdatok($id){
        try{
            $termek = $this->termekService->getTermek($id);
            
            if($termek != null){
                return response()->json($termek);
            } else{
                return response()->json(null, 404);
            }
        } catch(\Exception){
            return response()->json(null, 400);
        } 
    }
}