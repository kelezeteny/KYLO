<?php

namespace App\Services;

use App\Models\Termek;
use App\Repositories\TermekRepository;

class TermekService{
    private TermekRepository $termekRepository;

    public function __construct(){
        $this->termekRepository = new TermekRepository();
    }


    public function getTermekLista():?array{
        return $this->termekRepository->getTermekLista();
    }


    public function getTermek(int $id): ?Termek{
        return $this->termekRepository->getTermek($id);
    }
}