<?php

namespace App\Services;

use App\Repositories\KapcsolatRepository;

class KapcsolatService{
    private KapcsolatRepository $kapcsolatRepository;

    public function __construct(){
        $this->kapcsolatRepository = new KapcsolatRepository();
    }

    public function getFelhasznalok(){
        return $this->kapcsolatRepository->getFelhasznalok();
    }

    public function kapcsolat(){
        return $this->kapcsolatRepository->kapcsolat();
    }
}