<?php

namespace App\Repositories;
use App\Models\Termek;
use Illuminate\Support\Facades\DB;

class TermekRepository{
    public function getTermekLista() : ?array {
        try{
            $sql = "select * from termek order by id";
            $sqlResult = DB::select($sql);
            $result = [];

            foreach($sqlResult as $row){
                $termek = Termek::fromSqlRow($row);
                $result[] = $termek;
            }

            return $result;
            
        } catch(\Exception){
            return null;
        }
    }

    
    public function getTermek(int $id): ?Termek{
        try{
            $sql = "select * from termek where id = :id";
            $sqlResult = DB::select($sql, ['id' => $id]);

            if(count($sqlResult) != 1){
                return null;
            }

            return Termek::fromSqlRow($sqlResult[0]);

        } catch(\Exception){
            return null;
        }
    }
}