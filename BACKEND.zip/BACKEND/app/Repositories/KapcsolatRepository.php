<?php

namespace App\Repositories;
use App\Models\Kapcsolat;
use Illuminate\Support\Facades\DB;

class KapcsolatRepository{
    public function getFelhasznalok()  {
        return DB::select("select * from felhasznalo");
    }

    public function kapcsolat()
    {
        try {
            $data = request()->all();

            $felhasznalo = Kapcsolat::fromRequest($data);
            if ($felhasznalo === null) {
                return response()->json(['hibak' => ['Érvénytelen kérés.']], 400);
            }

            $sql = 'INSERT INTO felhasznalo (tel_szam, vezetek_nev, kereszt_nev, email)
                    VALUES (:tel_szam, :vezetek_nev, :kereszt_nev, :email)';

            DB::insert($sql, [
                'tel_szam'    => $felhasznalo->getTelSzam(),
                'vezetek_nev' => $felhasznalo->getVezetekNev(),
                'kereszt_nev' => $felhasznalo->getKeresztNev(),
                'email'       => $felhasznalo->getEmail(),
            ]);

        } catch (\Exception $e) {
            return response()->json(['hibak' => ['Érvénytelen kérés.']], 400);
        }
    }
}