<?php

namespace App\Models;

class Kapcsolat
{
    private string $telSzam;
    private string $vezeteknev;
    private string $keresztnev;
    private string $email;


    public function __construct(string $telSzam, string $vezeteknev, string $keresztnev, string $email){
        $this->telSzam = $telSzam;
        $this->vezeteknev = $vezeteknev;
        $this->keresztnev = $keresztnev;
        $this->email = $email;
    }


    public function getTelSzam()
    {
        return $this->telSzam;
    }
    public function setTelSzam($telSzam)
    {
        $this->telSzam = $telSzam;
        return $this;
    }
    
    public function getVezetekNev()
    {
        return $this->vezeteknev;
    }
    public function setVezetekNev($vezeteknev)
    {
        $this->vezeteknev = $vezeteknev;
        return $this;
    }

    public function getKeresztNev()
    {
        return $this->keresztnev;
    }
    public function setKeresztNev($keresztnev)
    {
        $this->keresztnev = $keresztnev;
        return $this;
    }

    public function getEmail()
    {
        return $this->email;
    }
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

    public static function fromRequest(array $data):?Kapcsolat{
        try{
            if(!is_string($data['telSzam']) ||
               !is_string($data['vezeteknev']) || 
               !is_string($data['keresztnev']) ||
               !is_string($data['email'])){
                return null;
            }

            return new Kapcsolat(
                telSzam: $data['telSzam'],
                vezeteknev: $data['vezeteknev'],
                keresztnev: $data['keresztnev'],
                email: $data['email']
            );

        } catch(\Exception){
            return null;
        }
    }
	
}