<?php

namespace App\Models;

class Galeria implements \JsonSerializable {
    private string $termekNev;
    private string $meret;
    private string $szin;
    private int $darabszam;

    public function __construct(string $termekNev, string $meret, string $szin, int $darabszam){
        $this->termekNev = $termekNev;
        $this->meret = $meret;
        $this->szin = $szin;
        $this->darabszam = $darabszam;
    }

    public function getTermekNev(): string{
        return $this->termekNev;
    }

    public function setTermekNev(string $termekNev): void {
        $this->termekNev = $termekNev;
    }

    public function getMeret(): string{
        return $this->meret;
    }

    public function setMeret(string $meret): void {
        $this->meret = $meret;
    }
    
    public function getSzin(): string{
        return $this->szin;
    }

    public function setSzin(string $szin): void {
        $this->szin = $szin;
    }
    
    public function getDarabszam(): int{
        return $this->darabszam;
    }

    public function setDarabszam(int $darabszam): void {
        $this->darabszam = $darabszam;
    }

    public static function fromSqlRow(object $row) : ?Galeria{
        try{
            return new Galeria($row->termekNev, 
                                   $row->meret,
                                    $row->szin,
                               $row->darabszam);
        } catch(\Exception){
            return null;
        }
    }
    
    public function jsonSerialize(): array {
        return get_object_vars($this);
    }
}