<?php

namespace App\Models;

class Termek implements \JsonSerializable {
    private int $id;
    private string $nev;
    private string $leiras;

    public function __construct(int $id, string $nev, string $leiras){
        $this->id = $id;
        $this->nev = $nev;
        $this->leiras = $leiras;
    }


    public function getId(): int{
        return $this->id;
    }

    public function setId(int $id): void{
        $this->id = $id;
    }

    public function getNev(): string{
        return $this->nev;
    }

    public function setNev(string $nev): void {
        $this->nev = $nev;
    }

    public function getLeiras(): string{
        return $this->leiras;
    }

    public function setLeiras(string $leiras): void {
        $this->leiras = $leiras;
    }    

    public static function fromSqlRow(object $row) : ?Termek{
        try{
            return new Termek($row->id, 
                               $row->nev, 
                               $row->leiras);
        } catch(\Exception){
            return null;
        }
    }
    
    public function jsonSerialize(): array {
        return get_object_vars($this);
    }
}