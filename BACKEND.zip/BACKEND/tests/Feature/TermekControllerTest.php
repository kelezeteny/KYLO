<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\TestCase;

class TermekControllerTest extends TestCase{
    public function testTermekListaWorking(){
        $response = $this->get("/termekek");
        $response->assertStatus(200);
    }

    public function testTermekWorking(){
        $validIds = [1, 2, 3];

        foreach($validIds as $id){
            $response = $this->get("/termekek/" . $id);
            $response->assertStatus(200);
        }
    }

    public function testTermekWorkingWithWrongIds(){
        $invalidIds = [20, 100];

        foreach($invalidIds as $id){
            $response = $this->get("/termekek/" . $id);
            $response->assertStatus(404);
        }
    }

}