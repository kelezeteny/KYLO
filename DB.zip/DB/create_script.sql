CREATE DATABASE kylo_project;

USE kylo_project;

CREATE TABLE termek_kategoria (
    kategoria_id integer  PRIMARY KEY AUTO_INCREMENT,
    kategoria_nev text NOT NULL
);

CREATE TABLE termek (
    id INT PRIMARY KEY AUTO_INCREMENT,
    termek_kategoria_id INT NOT NULL,
    nev text NOT NULL,
    leiras TEXT,
    FOREIGN KEY (termek_kategoria_id) REFERENCES termek_kategoria(kategoria_id)
);

CREATE TABLE szin (
    id int  PRIMARY KEY AUTO_INCREMENT,
    szin_nev text NOT NULL
);

CREATE TABLE meret ( 
    id int  PRIMARY KEY AUTO_INCREMENT,
    meret_nev text NOT NULL 
);

CREATE TABLE keszlet (
    id int PRIMARY KEY AUTO_INCREMENT,
    termek_id int NOT NULL,
    meret_id int NOT NULL, 
    szin_id int NOT NULL,
    darabszam int NOT NULL,
    FOREIGN KEY (termek_id) REFERENCES termek(id),
    FOREIGN KEY (meret_id) REFERENCES meret(id),
    FOREIGN KEY (szin_id) REFERENCES szin(id)
);

CREATE TABLE  felhasznalo ( 
    tel_szam int ,
	vezetek_nev TEXT,
	kereszt_nev text,
	email TEXT
    
);


INSERT INTO termek_kategoria (kategoria_nev) VALUES ('Póló');
INSERT INTO termek_kategoria (kategoria_nev) VALUES ('Pulóver');
INSERT INTO termek_kategoria (kategoria_nev) VALUES ('Nadrág');
 
INSERT INTO szin (szin_nev) VALUES ('fekete');
INSERT INTO szin (szin_nev) VALUES ('fehér');
INSERT INTO szin (szin_nev) VALUES ('szürke');
INSERT INTO szin (szin_nev) VALUES ('piros');


INSERT INTO meret (meret_nev) VALUES ('S');
INSERT INTO meret (meret_nev) VALUES ('M');
INSERT INTO meret (meret_nev) VALUES ('L');

INSERT INTO termek (termek_kategoria_id, nev, leiras) VALUES (1, 'KYLO Póló', 'Egyszerű pamut póló');


INSERT INTO termek (termek_kategoria_id, nev, leiras) VALUES (2, 'KYLO Pulóver', 'Meleg, kényelmes pulóver');


INSERT INTO termek (termek_kategoria_id, nev, leiras) VALUES (3, 'KYLO Nadrág', 'Kényelmes nadrág');




INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 1, 1, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 2, 1, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 3, 1, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 1, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 2, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 3, 2, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 1, 3, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 2, 3, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 3, 3, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 1, 4, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 2, 4, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (1, 3, 4, 5);  



INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 1, 1, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 2, 1, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 3, 1, 5); 

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 1, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 2, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 3, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 1, 3, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 2, 3, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 3, 3, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 1, 4, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 2, 4, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (2, 3, 4, 5);  


 
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 1, 1, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 2, 1, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 3, 1, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 1, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 2, 2, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 3, 2, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 1, 3, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 2, 3, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 3, 3, 5);  

INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 1, 4, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 2, 4, 5);  
INSERT INTO keszlet (termek_id, meret_id, szin_id, darabszam) VALUES (3, 3, 4, 5);  
